onEvent("gallery_home_btn", "click", function(event) {
	console.log("gallery_home_btn clicked!");
	setScreen("home");
});
onEvent("gallery_home_spanish_btn", "click", function(event) {
	console.log("gallery_home_spanish_btn clicked!");
	setScreen("home_spanish");
});
onEvent("home_location_btn", "click", function(event) {
	console.log("home_location_btn clicked!");
	setScreen("location");
});
onEvent("home_history_btn", "click", function(event) {
	console.log("home_history_btn clicked!");
	setScreen("history");
});
onEvent("home_trips_btn", "click", function(event) {
	console.log("home_trips_btn clicked!");
	setScreen("trips");
});
onEvent("home_gallery_btn", "click", function(event) {
  console.log("home_gallery_btn clicked!");
  setScreen("Gallery");
});
onEvent("home_spanish_btn", "click", function(event) {
	console.log("home_spanish_btn clicked!");
	setScreen("screen1");
});
onEvent("home_spanish_location_btn", "click", function(event) {
	console.log("home_spanish_location_btn clicked!");
	setScreen("location_spanish");
});
onEvent("home_spanish_history_btn", "click", function(event) {
	console.log("home_spanish_history_btn clicked!");
	setScreen("history_spanish");
});
onEvent("home_spanish_trips_btn", "click", function(event) {
	console.log("home_spanish_trips_btn clicked!");
	setScreen("trips_spanish");
});
onEvent("home_spanish_gallery_btn", "click", function(event) {
	console.log("home_spanish_gallery_btn clicked!");
	setScreen("Gallery");
});
onEvent("home_spanish_english_btn", "click", function(event) {
	console.log("home_spanish_english_btn clicked!");
	setScreen("home");
});
onEvent("location_home_btn", "click", function(event) {
	console.log("location_home_btn clicked!");
	setScreen("home");
});
onEvent("history_spanish_home_btn", "click", function(event) {
	console.log("history_spanish_home_btn clicked!");
	setScreen("home_spanish");
});
onEvent("history_home_btn", "click", function(event) {
	console.log("history_home_btn clicked!");
	setScreen("home");
});
onEvent("trips_home_btn", "click", function(event) {
	console.log("trips_home_btn clicked!");
	setScreen("home");
});
onEvent("home_spanish_btn", "click", function(event) {
	console.log("home_spanish_btn clicked!");
	setScreen("home_spanish");
});
onEvent("Location_spanish_home", "click", function(event) {
	console.log("Location_spanish_home clicked!");
	setScreen("home_spanish");
});
onEvent("trips_spanish_home_btn", "click", function(event) {
	console.log("trips_spanish_home_btn clicked!");
	setScreen("home_spanish");
});
onEvent("home_history_btn", "click", function(event) {
	console.log("home_history_btn clicked!");
	setScreen("screen1");
});
